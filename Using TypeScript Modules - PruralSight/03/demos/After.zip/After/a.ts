const aString = 'Welcome to TypeScript';
const bString = 'Something';
export { aString, bString };
export const fn = () => {};
//export default fn;

export { message } from './re-export';

export default 'default';

//export = 'test';