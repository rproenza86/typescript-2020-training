export function isOdd(input: number): boolean {
  return !!(input % 2);
}
