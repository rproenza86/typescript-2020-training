import { aString } from './a';
console.log(aString);